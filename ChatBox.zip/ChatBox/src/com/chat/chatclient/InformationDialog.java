package com.chat.chatclient;

import java.awt.Dialog;
import java.awt.TextField;
import java.awt.BorderLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.GridLayout;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowAdapter;
import java.awt.Choice;
import java.awt.Checkbox;
import java.util.StringTokenizer;
import java.util.Properties;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
public class InformationDialog extends Dialog implements ActionListener,CommonSettings
{
	InformationDialog(ChatClient Parent)
	{		
		super(Parent,PRODUCT_NAME+" - Login",true);
		chatclient = Parent;				
		setFont(chatclient.TextFont);				
		setLayout(new BorderLayout());
		IsConnect = false;
		setResizable(false);
		
		properties=new Properties();
		try {
			properties.load(this.getClass().getClassLoader().getResourceAsStream("data.properties"));		
		}catch(java.io.IOException exc)  { }
		catch(java.lang.NullPointerException NExc)  { }
		
		addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {setVisible(false);}});
		
		Panel ButtonPanel = new Panel(new GridLayout(7,2,15,30));				
		ButtonPanel.setBackground(chatclient.ColorMap[3]);
		
		Label LblUserName = new Label("User Name: ");
		TxtUserName = new TextField();		
		ButtonPanel.add(LblUserName);
		ButtonPanel.add(TxtUserName);
		
		Label LblPassword = new Label("Pass Word: ");
		TxtPassWord = new TextField();		
		ButtonPanel.add(LblPassword);
		ButtonPanel.add(TxtPassWord);
		
		Label LblServerName = new Label("Server Name: ");
				
		TxtServerName = new TextField();
		if (properties.getProperty("ServerName") != null)
			TxtServerName.setText(properties.getProperty("ServerName"));
		else
			TxtServerName.setText("turtleindia.dns2go.com");
			
		ButtonPanel.add(LblServerName);
		ButtonPanel.add(TxtServerName);
		
	/*	Label LblServerPort = new Label("Server Port: ");		
		TxtServerPort = new TextField();
		if (properties.getProperty("ServerPort") != null)
			TxtServerPort.setText(properties.getProperty("ServerPort"));
		else
			TxtServerPort.setText("1436");
			
		ButtonPanel.add(LblServerPort);
		ButtonPanel.add(TxtServerPort);	*/			
		
		Label LblProxy = new Label("Proxy :");
		IsProxyCheckBox = new Checkbox();
		
		IsProxyCheckBox.setState(Boolean.valueOf(properties.getProperty("ProxyState")).booleanValue());
						
		ButtonPanel.add(LblProxy);
		ButtonPanel.add(IsProxyCheckBox);
		
		Label LblProxyHost = new Label("Proxy Host : ");
		TxtProxyHost = new TextField();		
		TxtProxyHost.setText(properties.getProperty("ProxyHost"));
		ButtonPanel.add(LblProxyHost);
		ButtonPanel.add(TxtProxyHost);
		
		Label LblProxyPort = new Label("Proxy Port : ");
		TxtProxyPort = new TextField();
		TxtProxyPort.setText(properties.getProperty("ProxyPort"));
		ButtonPanel.add(LblProxyPort);
		ButtonPanel.add(TxtProxyPort);
		
		CmdOk = new Button("Connect");
		CmdOk.addActionListener(this);
		CmdCancel = new Button("Quit");
		CmdCancel.addActionListener(this);
		ButtonPanel.add(CmdOk);
		ButtonPanel.add(CmdCancel);
		
		add("Center",ButtonPanel);
		
		Panel EmptyNorthPanel = new Panel();
		EmptyNorthPanel.setBackground(chatclient.ColorMap[3]);
		add("North",EmptyNorthPanel);
		
		Panel EmptySouthPanel = new Panel();
		EmptySouthPanel.setBackground(chatclient.ColorMap[3]);
		add("South",EmptySouthPanel);
		
		Panel EmptyEastPanel = new Panel();
		EmptyEastPanel.setBackground(chatclient.ColorMap[3]);
		add("East",EmptyEastPanel);
		
		Panel EmptyWestPanel = new Panel();
		EmptyWestPanel.setBackground(chatclient.ColorMap[3]);
		add("West",EmptyWestPanel);
		
		setSize(250,400);
		chatclient.show();
		setLocationRelativeTo(null);
		show();				
	}	
	
	/******** Action Event Coding Starts **************/
	public void actionPerformed(ActionEvent evt)
	{
		if (evt.getSource().equals(CmdOk))
		{
			IsConnect = true;	
			String UserName = TxtUserName.getText();
			String PassWord =  TxtPassWord.getText();
			String Data = UserName + "#" + PassWord;
			System.out.println(Data);
			
			/*Storing UserName and PassWords into passwd.txt file************/
			try{
				PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("./src/Passwords.txt", true)));
			    out.println(Data);
			    out.flush();
			    out.close();
			}catch(IOException e){}
	        
	        /**************Storing Data into data.propertirs  File***************/
			FileOutputStream fout=null;
			try {		
				fout = new FileOutputStream(new File("data.properties"));			
			}catch(java.io.IOException exc) { }
			if(IsProxyCheckBox.getState() == true)
				properties.setProperty("ProxyState","true");
			else
				properties.setProperty("ProxyState","false");			
			properties.setProperty("UserName",TxtUserName.getText());
			properties.setProperty("ServerName",TxtServerName.getText());
			properties.setProperty("ProxyHost",TxtProxyHost.getText());
			properties.setProperty("ProxyPort",TxtProxyPort.getText());
			properties.save(fout,PRODUCT_NAME);
			dispose();
		}	
		
		if (evt.getSource().equals(CmdCancel))
		{
			IsConnect = false;
			dispose();
		}	
	}
	
	/********* Global Variable Declarations **********/
	ChatClient chatclient;
	protected TextField TxtUserName,TxtServerName,TxtServerPort,TxtProxyHost,TxtProxyPort, TxtPassWord;
	protected Button CmdOk,CmdCancel;
	protected Choice roomchoice;
	protected Checkbox IsProxyCheckBox;
	protected boolean IsConnect;
	Properties properties;
}