package com.chat.chatclient;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

public class LoginPage extends Dialog implements ActionListener,CommonSettings {

	LoginPage(ChatClient client){
		super(client,PRODUCT_NAME+" - Login",true);
		chatclient = client;				
		setFont(chatclient.TextFont);				
		
		IsConnect = false;
		setLocationRelativeTo(null);
		
		addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {setVisible(false);}});
		
		Panel ButtonPanel = new Panel();	
		
		ButtonPanel.setBackground(chatclient.ColorMap[3]);
		 
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    int screenHeight = screenSize.height;
	    int screenWidth = screenSize.width;
	    this.setLocation(screenWidth/3, screenHeight/4);
	    		
		Label LblUserName = new Label("User Name: ");
		LblUserName.setPreferredSize(new Dimension(150, 20));
		TxtUserName = new TextField();
		TxtUserName.setPreferredSize(new Dimension(150, 20));
		ButtonPanel.add(LblUserName);
		ButtonPanel.add(TxtUserName);
		
		Label LblServerName = new Label("Pass Word: ");	
		LblServerName.setPreferredSize(new Dimension(150, 20));
		TxtPassWord = new TextField();
		TxtPassWord.setEchoChar('*');
		TxtPassWord.setPreferredSize(new Dimension(150, 20));
			
		ButtonPanel.add(LblServerName);
		ButtonPanel.add(TxtPassWord);
		
		CmdOk = new Button("Connect");
		CmdOk.setPreferredSize(new Dimension(100, 30));
		CmdOk.addActionListener(this);
		CmdCancel = new Button("Quit");
		CmdCancel.setPreferredSize(new Dimension(100, 30));
		CmdCancel.addActionListener(this);
		cmdSignUp = new Button("SignUp");
		cmdSignUp.setPreferredSize(new Dimension(100, 30));
		cmdSignUp.addActionListener(this);
		
		ButtonPanel.add(CmdOk);
		ButtonPanel.add(CmdCancel);
		ButtonPanel.add(cmdSignUp);
		
		add("Center",ButtonPanel);
		
	 	setSize(350,200);
		chatclient.show();
		show();				
	} 
	 
	public void actionPerformed(ActionEvent e) {
		String Username = TxtUserName.getText();
		String Password = TxtPassWord.getText();
		
		if (e.getSource().equals(CmdOk))
		{
			IsConnect = false;
			try {
				if(IsUserExist(Username, Password))
				{	
					IsConnect = true;
					dispose(); 
				 	
				}
				else{
					JOptionPane.showMessageDialog(this, "You are Not Aoutherised User Please singup!");
					
				}
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getSource().equals(CmdCancel))
		{
			
			IsConnect = false;
			dispose();
		}	
		if (e.getSource().equals(cmdSignUp))
		{	dispose();
			dialog = new InformationDialog(chatclient);
		}	
			
	}
	private boolean IsUserExist(String Username, String Password) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File("D:\\ChatBox\\src\\Passwords.txt")));
		 String line=""; boolean value = false;
		while((line = br.readLine()) != null){
			String userpass[] = line.split("#");
			
			if((Username.equals(userpass[0])) && (Password.equals(userpass[1])))
			{
				value = true;
				return value;
			}else 
			{
				value = false;
				 
			}
		} 
		return value;
		
		 
	
	}
	
	protected TextField TxtUserName,TxtServerName,TxtServerPort,TxtProxyHost,TxtProxyPort, TxtPassWord;
	protected Button CmdOk,CmdCancel,cmdSignUp;
	protected Choice roomchoice;
	protected Checkbox IsProxyCheckBox;
	protected boolean IsConnect;
	ChatClient chatclient;
	Properties properties;
	InformationDialog dialog;
}
